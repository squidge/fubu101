﻿$(document).ready(function () {
    $('#authorization-rules').accordion({
        collapsible:true
    });
});